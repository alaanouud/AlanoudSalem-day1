package com.example.projec2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projec2Application {

    public static void main(String[] args) {
        SpringApplication.run(Projec2Application.class, args);
    }

}
