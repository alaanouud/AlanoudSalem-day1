package com.example.projec2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projec2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
